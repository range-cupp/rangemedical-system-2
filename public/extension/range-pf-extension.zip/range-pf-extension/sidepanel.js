// ============================================
// RANGE MEDICAL → PRACTICE FUSION EXTENSION
// Side Panel v1.4.1
// FIX: setVal crash on SELECT elements that blocked DOB + Gender
// FIX: Documents download to Downloads folder
// ============================================

const SUPABASE_URL = 'https://teivfptpozltpqwahgdl.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRlaXZmcHRwb3psdHBxd2FoZ2RsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ3MTMxNDksImV4cCI6MjA4MDI4OTE0OX0.NrI1AykMBOh91mM9BFvpSH0JwzGrkv5ADDkZinh0elc';
const GHL_API_KEY = 'pit-0967834a-726c-4076-aeec-a4216e5c6c83';
const GHL_LOCATION_ID = 'WICdvbXmTjQORW6GiHWW';
const CURRENT_VERSION = '1.4.1';
const VERSION_CHECK_URL = 'https://app.range-medical.com/api/extension/version';
const DOWNLOAD_URL = 'https://app.range-medical.com/api/extension/download';

let selectedPatient = null;
let selectedAppointment = null;
let currentScheduleDate = new Date();

const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');
const resultsSection = document.getElementById('resultsSection');
const actionsSection = document.getElementById('actionsSection');
const statusEl = document.getElementById('statusMessage');
const pageIndicator = document.getElementById('pageIndicator');
const fillDemographicsBtn = document.getElementById('fillDemographicsBtn');
const fillAppointmentBtn = document.getElementById('fillAppointmentBtn');
const scheduleDate = document.getElementById('scheduleDate');
const loadScheduleBtn = document.getElementById('loadScheduleBtn');
const scheduleSection = document.getElementById('scheduleSection');
const scheduleSummary = document.getElementById('scheduleSummary');
const prevDayBtn = document.getElementById('prevDayBtn');
const nextDayBtn = document.getElementById('nextDayBtn');

// ============================================
// INIT
// ============================================
document.addEventListener('DOMContentLoaded', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.url) detectPage(tab.url);
  
  const today = new Date();
  scheduleDate.value = formatDateForInput(today);
  currentScheduleDate = today;
  
  searchBtn.addEventListener('click', handleSearch);
  searchInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') handleSearch(); });
  fillDemographicsBtn.addEventListener('click', () => fillDemographics());
  fillAppointmentBtn.addEventListener('click', () => fillAppointment());
  loadScheduleBtn.addEventListener('click', loadDailySchedule);
  prevDayBtn.addEventListener('click', () => changeDate(-1));
  nextDayBtn.addEventListener('click', () => changeDate(1));
  scheduleDate.addEventListener('change', () => { currentScheduleDate = new Date(scheduleDate.value + 'T12:00:00'); });
  
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => switchTab(tab.dataset.tab));
  });
  
  checkForUpdates();
});

function detectPage(url) {
  if (!url) return;
  if (url.includes('charts/patients/add')) {
    pageIndicator.textContent = '📝 Ready to fill patient demographics';
    pageIndicator.style.display = 'block';
  } else if (url.includes('/schedule')) {
    pageIndicator.textContent = '📅 Ready to fill appointment';
    pageIndicator.style.display = 'block';
  } else if (url.includes('/charts/') && url.includes('/documents')) {
    pageIndicator.textContent = '📄 Ready to upload documents';
    pageIndicator.style.display = 'block';
  } else if (url.includes('practicefusion.com')) {
    pageIndicator.style.display = 'none';
  } else {
    pageIndicator.textContent = '⚠️ Open Practice Fusion to use this extension';
    pageIndicator.style.display = 'block';
  }
}

function switchTab(tabName) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelector(`.tab[data-tab="${tabName}"]`).classList.add('active');
  document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
  document.getElementById(tabName === 'search' ? 'searchTab' : 'scheduleTab').classList.add('active');
}

// ============================================
// VERSION CHECK
// ============================================
async function checkForUpdates() {
  try {
    const response = await fetch(VERSION_CHECK_URL);
    if (!response.ok) return;
    const data = await response.json();
    if (data.version && isNewerVersion(data.version, CURRENT_VERSION)) {
      showUpdateBanner(data.version, data.notes || 'New version available');
    }
  } catch (e) { console.log('Update check skipped:', e.message); }
}

function isNewerVersion(remote, local) {
  const r = remote.split('.').map(Number);
  const l = local.split('.').map(Number);
  for (let i = 0; i < Math.max(r.length, l.length); i++) {
    if ((r[i] || 0) > (l[i] || 0)) return true;
    if ((r[i] || 0) < (l[i] || 0)) return false;
  }
  return false;
}

function showUpdateBanner(newVersion, notes) {
  const container = document.getElementById('updateBannerContainer');
  container.innerHTML = `
    <div style="background:linear-gradient(135deg,#0ea5e9,#0284c7);color:white;padding:12px 16px;border-radius:10px;margin-bottom:16px;">
      <div style="font-weight:600;margin-bottom:4px;">🎉 Update Available (v${newVersion})</div>
      <div style="font-size:12px;opacity:0.9;margin-bottom:10px;">${notes}</div>
      <button id="downloadUpdate" style="background:white;color:#0284c7;border:none;padding:8px 16px;border-radius:6px;font-weight:500;cursor:pointer;font-size:13px;">Download Update</button>
      <button id="dismissUpdate" style="background:transparent;color:white;border:1px solid rgba(255,255,255,0.3);padding:8px 12px;border-radius:6px;margin-left:8px;cursor:pointer;font-size:13px;">Later</button>
    </div>`;
  document.getElementById('downloadUpdate').addEventListener('click', () => window.open(DOWNLOAD_URL, '_blank'));
  document.getElementById('dismissUpdate').addEventListener('click', () => container.innerHTML = '');
}

// ============================================
// SEARCH
// ============================================
async function handleSearch() {
  const query = searchInput.value.trim();
  if (!query) return;
  
  resultsSection.innerHTML = '<div class="no-results">Searching...</div>';
  actionsSection.style.display = 'none';
  selectedPatient = null;
  selectedAppointment = null;
  
  try {
    const patients = await searchPatients(query);
    if (patients.length === 0) {
      resultsSection.innerHTML = '<div class="no-results">No patients found</div>';
      return;
    }
    displayResults(patients);
  } catch (error) {
    console.error('Search error:', error);
    resultsSection.innerHTML = `<div class="no-results">Error: ${error.message}</div>`;
  }
}

async function searchPatients(query) {
  const isPhone = /^\d{3,}$/.test(query.replace(/\D/g, ''));
  let patients = [];
  
  if (isPhone) {
    const cleanPhone = query.replace(/\D/g, '');
    const url = `${SUPABASE_URL}/rest/v1/intakes?phone=ilike.*${cleanPhone}*&select=*&limit=10`;
    const response = await fetch(url, { headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` } });
    if (response.ok) patients = await response.json();
  } else {
    const parts = query.split(' ');
    const firstName = parts[0];
    const lastName = parts.slice(1).join(' ') || firstName;
    
    let url = `${SUPABASE_URL}/rest/v1/intakes?first_name=ilike.*${encodeURIComponent(firstName)}*&last_name=ilike.*${encodeURIComponent(lastName)}*&select=*&limit=10`;
    let response = await fetch(url, { headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` } });
    if (response.ok) patients = await response.json();
    
    if (patients.length === 0 && parts.length === 1) {
      url = `${SUPABASE_URL}/rest/v1/intakes?or=(first_name.ilike.*${encodeURIComponent(firstName)}*,last_name.ilike.*${encodeURIComponent(firstName)}*)&select=*&limit=10`;
      response = await fetch(url, { headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` } });
      if (response.ok) patients = await response.json();
    }
  }
  
  if (patients.length === 0) {
    try { patients = await searchGHLContacts(query); } catch (e) { console.log('GHL fallback error:', e); }
  }
  
  for (const patient of patients) {
    patient.documents = await fetchDocuments(patient);
    patient.appointments = await fetchAppointments(patient.phone);
  }
  
  return patients;
}

async function searchGHLContacts(query) {
  try {
    const isPhone = /^\d{3,}$/.test(query.replace(/\D/g, ''));
    let url;
    if (isPhone) {
      url = `${SUPABASE_URL}/rest/v1/ghl_contacts?phone=ilike.*${query.replace(/\D/g, '')}*&select=*&limit=10`;
    } else {
      const parts = query.split(' ');
      const firstName = parts[0];
      const lastName = parts.slice(1).join(' ') || '';
      if (lastName) {
        url = `${SUPABASE_URL}/rest/v1/ghl_contacts?first_name=ilike.*${encodeURIComponent(firstName)}*&last_name=ilike.*${encodeURIComponent(lastName)}*&select=*&limit=10`;
      } else {
        url = `${SUPABASE_URL}/rest/v1/ghl_contacts?or=(first_name.ilike.*${encodeURIComponent(firstName)}*,last_name.ilike.*${encodeURIComponent(firstName)}*)&select=*&limit=10`;
      }
    }
    const response = await fetch(url, { headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` } });
    if (!response.ok) return [];
    const contacts = await response.json();
    return contacts.map(c => ({
      first_name: c.first_name, last_name: c.last_name, email: c.email, phone: c.phone,
      date_of_birth: c.date_of_birth, gender: c.gender,
      street_address: c.address1 || c.street_address, city: c.city, state: c.state,
      postal_code: c.postal_code || c.zip, source: 'ghl', ghl_contact_id: c.ghl_contact_id
    }));
  } catch (e) { console.error('GHL contacts search error:', e); return []; }
}

// ============================================
// DOCUMENTS
// ============================================
async function fetchDocuments(patient) {
  const allDocs = [];
  const { phone, email, first_name: firstName, last_name: lastName } = patient;
  
  if (patient.pdf_url) allDocs.push({ type: 'Medical Intake Form', url: patient.pdf_url });
  
  try {
    // By phone
    if (phone) {
      const last7 = phone.replace(/\D/g, '').slice(-7);
      if (last7) {
        const res = await fetch(`${SUPABASE_URL}/rest/v1/consents?phone=ilike.*${last7}*&select=*`, { headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` } });
        if (res.ok) {
          const consents = await res.json();
          consents.forEach(c => { if (c.pdf_url && !allDocs.find(d => d.url === c.pdf_url)) allDocs.push({ type: c.consent_type || 'Consent Form', url: c.pdf_url }); });
        }
      }
    }
    // By email
    if (email) {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/consents?email=ilike.*${encodeURIComponent(email)}*&select=*`, { headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` } });
      if (res.ok) {
        const consents = await res.json();
        consents.forEach(c => { if (c.pdf_url && !allDocs.find(d => d.url === c.pdf_url)) allDocs.push({ type: c.consent_type || 'Consent Form', url: c.pdf_url }); });
      }
    }
    // By name
    if (firstName && lastName) {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/consents?first_name=ilike.*${encodeURIComponent(firstName)}*&last_name=ilike.*${encodeURIComponent(lastName)}*&select=*`, { headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` } });
      if (res.ok) {
        const consents = await res.json();
        consents.forEach(c => { if (c.pdf_url && !allDocs.find(d => d.url === c.pdf_url)) allDocs.push({ type: c.consent_type || 'Consent Form', url: c.pdf_url }); });
      }
    }
  } catch (e) { console.log('Document fetch error:', e); }
  
  return allDocs;
}

// ============================================
// GHL APPOINTMENTS
// ============================================
async function fetchAppointments(phone) {
  if (!phone) return [];
  try {
    const cleanPhone = phone.replace(/\D/g, '');
    let contactId = null;
    
    // Method 1: Supabase ghl_contacts table
    const last7 = cleanPhone.slice(-7);
    try {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/ghl_contacts?phone=ilike.*${last7}*&select=ghl_contact_id&limit=1`, { headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` } });
      if (res.ok) { const results = await res.json(); if (results[0]?.ghl_contact_id) contactId = results[0].ghl_contact_id; }
    } catch (e) {}
    
    // Method 2: GHL API search
    if (!contactId) {
      try {
        const searchUrl = `https://services.leadconnectorhq.com/contacts/?locationId=${GHL_LOCATION_ID}&query=${cleanPhone}&limit=5`;
        const res = await fetch(searchUrl, { headers: { 'Authorization': `Bearer ${GHL_API_KEY}`, 'Version': '2021-07-28' } });
        if (res.ok) { const data = await res.json(); if (data.contacts?.length > 0) contactId = data.contacts[0].id; }
      } catch (e) {}
    }
    
    if (!contactId) return [];
    
    const apptUrl = `https://services.leadconnectorhq.com/contacts/${contactId}/appointments?locationId=${GHL_LOCATION_ID}`;
    const apptRes = await fetch(apptUrl, { headers: { 'Authorization': `Bearer ${GHL_API_KEY}`, 'Version': '2021-07-28' } });
    if (!apptRes.ok) return [];
    
    const apptData = await apptRes.json();
    const appointments = apptData.events || apptData.appointments || [];
    
    const now = new Date();
    const pastDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const futureDate = new Date(now.getTime() + 90 * 24 * 60 * 60 * 1000);
    
    return appointments.filter(a => {
      const d = new Date(a.startTime || a.start_time);
      return d >= pastDate && d <= futureDate;
    }).sort((a, b) => new Date(a.startTime || a.start_time) - new Date(b.startTime || b.start_time));
  } catch (error) {
    console.error('Error fetching appointments:', error);
    return [];
  }
}

// ============================================
// DISPLAY RESULTS
// ============================================
function displayResults(patients) {
  resultsSection.innerHTML = '';
  patients.forEach((patient) => {
    const card = document.createElement('div');
    card.className = 'patient-card';
    card.innerHTML = `
      <div class="patient-name">${patient.first_name || ''} ${patient.last_name || ''}</div>
      <div class="patient-detail">📱 ${formatPhone(patient.phone) || 'No phone'}</div>
      ${patient.email ? `<div class="patient-detail">✉️ ${patient.email}</div>` : ''}
      ${patient.date_of_birth ? `<div class="patient-detail">🎂 ${formatDate(patient.date_of_birth)}</div>` : ''}
      ${patient.source === 'ghl' ? '<div class="patient-detail" style="color:#0ea5e9;">From GHL Contacts</div>' : ''}
    `;
    card.addEventListener('click', () => selectPatient(patient, card));
    resultsSection.appendChild(card);
  });
}

function selectPatient(patient, card) {
  document.querySelectorAll('.patient-card').forEach(c => c.classList.remove('selected'));
  card.classList.add('selected');
  selectedPatient = patient;
  actionsSection.style.display = 'block';
  
  document.getElementById('selectedInfo').innerHTML = `
    <div class="patient-card selected" style="cursor:default;">
      <div class="patient-name">Selected: ${patient.first_name} ${patient.last_name}</div>
      <div class="patient-detail">📱 ${formatPhone(patient.phone) || 'N/A'} | ✉️ ${patient.email || 'N/A'}</div>
      ${patient.date_of_birth ? `<div class="patient-detail">🎂 ${formatDate(patient.date_of_birth)} | ⚧ ${patient.gender || 'N/A'}</div>` : ''}
      ${patient.street_address ? `<div class="patient-detail">📍 ${patient.street_address}, ${patient.city || ''} ${patient.state || ''} ${patient.postal_code || ''}</div>` : ''}
    </div>`;
  
  // Documents - with Download buttons
  const docsSection = document.getElementById('documentsSection');
  if (patient.documents?.length > 0) {
    docsSection.innerHTML = '<div style="font-weight:600;font-size:13px;margin:12px 0 8px;">📄 Documents</div>';
    patient.documents.forEach(doc => {
      const docEl = document.createElement('div');
      docEl.className = 'doc-item';
      
      // Extract filename from URL
      const urlParts = doc.url.split('/');
      const rawFilename = urlParts[urlParts.length - 1] || doc.type;
      const filename = `${patient.first_name}_${patient.last_name}_${doc.type.replace(/\s+/g, '_')}.pdf`;
      
      docEl.innerHTML = `
        <div>
          <div class="doc-name">${doc.type}</div>
        </div>
        <div style="display:flex;gap:4px;">
          <button class="doc-btn doc-btn-download" data-url="${doc.url}" data-filename="${filename}">⬇ Download</button>
          <button class="doc-btn doc-btn-open" data-url="${doc.url}">Open ↗</button>
        </div>
      `;
      docsSection.appendChild(docEl);
    });
    
    // Attach download handlers
    docsSection.querySelectorAll('.doc-btn-download').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const url = e.target.dataset.url;
        const filename = e.target.dataset.filename;
        downloadDocument(url, filename, e.target);
      });
    });
    docsSection.querySelectorAll('.doc-btn-open').forEach(btn => {
      btn.addEventListener('click', (e) => {
        window.open(e.target.dataset.url, '_blank');
      });
    });
  } else {
    docsSection.innerHTML = '<div class="no-results" style="padding:8px;">No documents found</div>';
  }
  
  // Appointments
  const apptSection = document.getElementById('appointmentsSection');
  if (patient.appointments?.length > 0) {
    apptSection.innerHTML = '<div style="font-weight:600;font-size:13px;margin:12px 0 8px;">📅 Appointments</div>';
    patient.appointments.forEach((appt, i) => {
      const startTime = new Date(appt.startTime || appt.start_time);
      const apptEl = document.createElement('div');
      apptEl.className = 'appointment-card';
      if (i === 0) { apptEl.style.borderColor = '#000'; selectedAppointment = appt; }
      apptEl.innerHTML = `
        <div class="appt-title">${appt.title || appt.calendarName || 'Appointment'}</div>
        <div class="appt-detail">${startTime.toLocaleDateString()} at ${startTime.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>
        ${appt.status ? `<div class="appt-detail">Status: ${appt.status}</div>` : ''}
      `;
      apptEl.addEventListener('click', () => {
        document.querySelectorAll('.appointment-card').forEach(a => a.style.borderColor = '#bae6fd');
        apptEl.style.borderColor = '#000';
        selectedAppointment = appt;
      });
      apptSection.appendChild(apptEl);
    });
  } else {
    apptSection.innerHTML = '<div class="no-results" style="padding:8px;">No upcoming appointments</div>';
  }
  
  showStatus(null);
}

// ============================================
// DOWNLOAD DOCUMENTS TO DOWNLOADS FOLDER
// ============================================
async function downloadDocument(url, filename, buttonEl) {
  const originalText = buttonEl.textContent;
  buttonEl.textContent = '⏳ ...';
  buttonEl.disabled = true;
  
  try {
    // Use background script to trigger Chrome download
    chrome.runtime.sendMessage({ action: 'downloadFile', url, filename }, (response) => {
      if (response?.success) {
        buttonEl.textContent = '✓ Done';
        buttonEl.style.background = '#10b981';
        setTimeout(() => {
          buttonEl.textContent = originalText;
          buttonEl.style.background = '';
          buttonEl.disabled = false;
        }, 2000);
      } else {
        // Fallback: use fetch + blob download
        fallbackDownload(url, filename, buttonEl, originalText);
      }
    });
  } catch (e) {
    fallbackDownload(url, filename, buttonEl, originalText);
  }
}

async function fallbackDownload(url, filename, buttonEl, originalText) {
  try {
    const response = await fetch(url);
    const blob = await response.blob();
    const blobUrl = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = blobUrl;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(blobUrl);
    buttonEl.textContent = '✓ Done';
    buttonEl.style.background = '#10b981';
  } catch (e) {
    buttonEl.textContent = '✗ Error';
    buttonEl.style.background = '#ef4444';
  }
  setTimeout(() => {
    buttonEl.textContent = originalText;
    buttonEl.style.background = '';
    buttonEl.disabled = false;
  }, 2000);
}

// ============================================
// FILL DEMOGRAPHICS (v1.4.1 - FIXED)
// ============================================
async function fillDemographics() {
  if (!selectedPatient) { showStatus('Please select a patient first', 'error'); return; }
  showStatus('Filling demographics...', 'info');
  
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  const patient = {
    firstName: selectedPatient.first_name?.trim(),
    lastName: selectedPatient.last_name?.trim(),
    email: selectedPatient.email,
    phone: selectedPatient.phone,
    dob: selectedPatient.date_of_birth,
    gender: selectedPatient.gender,
    address: selectedPatient.street_address,
    city: selectedPatient.city,
    state: selectedPatient.state,
    zip: selectedPatient.postal_code
  };
  
  console.log('📝 Sending patient data to fill:', patient);
  
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: fillPFDemographics,
      args: [patient]
    });
    const result = results?.[0]?.result;
    if (result?.success) {
      const msg = `✓ Filled ${result.fieldsSet} fields!`;
      const notes = result.notes ? ` Note: ${result.notes}` : '';
      showStatus(msg + notes, 'success');
    } else {
      showStatus(`Failed: ${result?.error || 'Unknown error'}`, 'error');
    }
  } catch (error) {
    console.error('Fill error:', error);
    showStatus('Failed to fill. Make sure you\'re on the Add Patient page.', 'error');
  }
}

// ============================================
// THIS FUNCTION RUNS ON THE PRACTICE FUSION PAGE
// v1.4.1 - Fixed: setVal no longer crashes on SELECT elements
// Now DOB and Gender actually get reached and filled
// ============================================
function fillPFDemographics(patient) {
  console.log('🏥 v1.4.1 Filling demographics for:', patient);
  
  let filled = 0;
  let notes = [];
  
  // ---- Find input by label text ----
  function findByLabel(labelText) {
    const labels = document.querySelectorAll('label');
    for (const label of labels) {
      const text = label.textContent.trim().toUpperCase().replace(/\*/g, '').trim();
      if (text === labelText.toUpperCase() || text.startsWith(labelText.toUpperCase())) {
        const forId = label.getAttribute('for');
        if (forId) { const el = document.getElementById(forId); if (el) return el; }
        const input = label.querySelector('input, select, textarea');
        if (input) return input;
        let next = label.nextElementSibling;
        while (next) {
          if (['INPUT','SELECT','TEXTAREA'].includes(next.tagName)) return next;
          const inner = next.querySelector('input, select, textarea');
          if (inner) return inner;
          next = next.nextElementSibling;
        }
        const parent = label.parentElement;
        if (parent) {
          let pNext = parent.nextElementSibling;
          while (pNext) {
            const inner = pNext.querySelector('input, select, textarea');
            if (inner) return inner;
            if (['INPUT','SELECT','TEXTAREA'].includes(pNext.tagName)) return pNext;
            pNext = pNext.nextElementSibling;
          }
        }
      }
    }
    return null;
  }
  
  function findByDataElement(name) {
    return document.querySelector(`[data-element="${name}"]`);
  }
  
  // ---- FIXED: Set value safely - checks element type before using native setter ----
  function setVal(el, val) {
    if (!el || !val) return false;
    try {
      const tag = el.tagName;
      if (tag === 'SELECT') {
        // For SELECT elements, set value directly and dispatch change
        el.value = val;
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      }
      // For INPUT and TEXTAREA, use native setter to bypass frameworks
      if (tag === 'INPUT') {
        const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
        if (nativeSetter) { nativeSetter.call(el, val); } else { el.value = val; }
      } else if (tag === 'TEXTAREA') {
        const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;
        if (nativeSetter) { nativeSetter.call(el, val); } else { el.value = val; }
      } else {
        el.value = val;
      }
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.dispatchEvent(new Event('blur', { bubbles: true }));
      return true;
    } catch (e) {
      console.log('setVal error for', el.tagName, ':', e.message, '- falling back to direct set');
      try {
        el.value = val;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      } catch (e2) {
        console.log('setVal fallback also failed:', e2.message);
        return false;
      }
    }
  }
  
  function setDropdown(el, value) {
    if (!el || !value || el.tagName !== 'SELECT') return false;
    const options = el.querySelectorAll('option');
    for (const opt of options) {
      if (opt.textContent.trim().toLowerCase().includes(value.toLowerCase()) ||
          opt.value.toLowerCase() === value.toLowerCase()) {
        el.value = opt.value;
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      }
    }
    return false;
  }
  
  // ==== FILL TEXT FIELDS ====
  
  if (patient.firstName) {
    const el = findByDataElement('first-name') || findByLabel('FIRST');
    if (setVal(el, patient.firstName)) { filled++; console.log('✓ First name filled'); }
    else console.log('⚠ First name field not found');
  }
  
  if (patient.lastName) {
    const el = findByDataElement('last-name') || findByLabel('LAST');
    if (setVal(el, patient.lastName)) { filled++; console.log('✓ Last name filled'); }
    else console.log('⚠ Last name field not found');
  }
  
  if (patient.email) {
    const el = findByDataElement('email-address') || findByLabel('EMAIL') || document.querySelector('input[type="email"]');
    if (setVal(el, patient.email)) { filled++; console.log('✓ Email filled'); }
    else console.log('⚠ Email field not found');
  }
  
  if (patient.phone) {
    const digits = patient.phone.replace(/\D/g, '');
    const clean = digits.length > 10 ? digits.slice(-10) : digits;
    const el = findByDataElement('mobile-phone') || findByLabel('MOBILE');
    if (setVal(el, clean)) { filled++; console.log('✓ Phone filled'); }
    else console.log('⚠ Phone field not found');
  }
  
  if (patient.address) {
    const el = findByDataElement('address-line1') || findByLabel('ADDRESS LINE 1') || findByLabel('ADDRESS');
    if (setVal(el, patient.address)) { filled++; console.log('✓ Address filled'); }
    else console.log('⚠ Address field not found');
  }
  
  if (patient.city) {
    const el = findByDataElement('city') || findByLabel('CITY');
    if (setVal(el, patient.city)) { filled++; console.log('✓ City filled'); }
    else console.log('⚠ City field not found');
  }
  
  if (patient.zip) {
    const el = findByDataElement('zip') || findByLabel('ZIP');
    if (setVal(el, patient.zip)) { filled++; console.log('✓ ZIP filled'); }
    else console.log('⚠ ZIP field not found');
  }
  
  // ==== STATE (dropdown) ====
  if (patient.state) {
    const stateField = findByDataElement('state') || findByLabel('STATE');
    if (stateField) {
      if (stateField.tagName === 'SELECT') {
        if (setDropdown(stateField, patient.state)) { filled++; console.log('✓ State selected'); }
        else console.log('⚠ State option not found for:', patient.state);
      } else {
        if (setVal(stateField, patient.state)) { filled++; console.log('✓ State filled'); }
      }
    } else console.log('⚠ State field not found');
  }
  
  // ==== DATE OF BIRTH ====
  if (patient.dob) {
    console.log('🎂 Attempting DOB fill with:', patient.dob);
    const dobField = findByDataElement('date-of-birth') || findByLabel('DATE OF BIRTH') || findByLabel('DOB');
    
    if (dobField) {
      let month, day, year;
      if (patient.dob.includes('-')) {
        [year, month, day] = patient.dob.split('-');
      } else if (patient.dob.includes('/')) {
        [month, day, year] = patient.dob.split('/');
      }
      
      if (month && day && year) {
        const formatted = `${month.padStart(2, '0')}/${day.padStart(2, '0')}/${year}`;
        console.log('DOB formatted:', formatted);
        
        // Set value using safe method
        if (setVal(dobField, formatted)) {
          console.log('✓ DOB filled via setVal');
        }
        
        // Also simulate keystrokes for masked inputs
        try {
          dobField.focus();
          if (dobField.select) dobField.select();
          
          // Clear field
          dobField.dispatchEvent(new KeyboardEvent('keydown', { key: 'a', ctrlKey: true, bubbles: true }));
          dobField.dispatchEvent(new KeyboardEvent('keydown', { key: 'Delete', bubbles: true }));
          
          // Type each character
          for (const char of formatted.split('')) {
            dobField.dispatchEvent(new KeyboardEvent('keydown', { key: char, bubbles: true }));
            dobField.dispatchEvent(new KeyboardEvent('keypress', { key: char, bubbles: true }));
            dobField.dispatchEvent(new InputEvent('input', { data: char, inputType: 'insertText', bubbles: true }));
            dobField.dispatchEvent(new KeyboardEvent('keyup', { key: char, bubbles: true }));
          }
          
          dobField.dispatchEvent(new Event('change', { bubbles: true }));
          dobField.dispatchEvent(new Event('blur', { bubbles: true }));
        } catch (e) {
          console.log('DOB keystroke simulation error (non-fatal):', e.message);
        }
        
        // Handle native date inputs
        if (dobField.type === 'date') {
          try {
            dobField.value = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
            dobField.dispatchEvent(new Event('change', { bubbles: true }));
          } catch (e) {}
        }
        
        filled++;
        console.log('✓ DOB filled:', formatted);
      } else {
        console.log('⚠ Could not parse DOB:', patient.dob);
        notes.push('Could not parse date of birth');
      }
    } else {
      console.log('⚠ DOB field not found on page');
      notes.push('DOB field not found');
    }
  }
  
  // ==== SEX / GENDER ====
  if (patient.gender) {
    console.log('⚧ Attempting gender/sex fill with:', patient.gender);
    let genderSet = false;
    const genderLower = patient.gender.toLowerCase().trim();
    
    let targetValues = [];
    if (genderLower === 'male' || genderLower === 'm') {
      targetValues = ['male', 'm'];
    } else if (genderLower === 'female' || genderLower === 'f') {
      targetValues = ['female', 'f'];
    } else if (genderLower === 'unknown') {
      targetValues = ['unknown', 'u'];
    } else {
      targetValues = [genderLower];
    }
    
    const allRadios = document.querySelectorAll('input[type="radio"]');
    console.log('Found', allRadios.length, 'radio buttons on page');
    
    // Strategy 1: Match by radio value
    for (const radio of allRadios) {
      const radioVal = (radio.value || '').toLowerCase();
      if (targetValues.includes(radioVal)) {
        console.log('Found radio by value:', radio.value);
        radio.checked = true;
        radio.click();
        radio.dispatchEvent(new Event('change', { bubbles: true }));
        genderSet = true;
        break;
      }
    }
    
    // Strategy 2: Match by label text
    if (!genderSet) {
      for (const radio of allRadios) {
        const label = document.querySelector(`label[for="${radio.id}"]`) || radio.closest('label');
        const labelText = (label?.textContent || '').toLowerCase().trim();
        if (targetValues.some(tv => labelText.includes(tv))) {
          console.log('Found radio by label:', labelText);
          radio.checked = true;
          radio.click();
          radio.dispatchEvent(new Event('change', { bubbles: true }));
          genderSet = true;
          break;
        }
      }
    }
    
    // Strategy 3: Find radios near SEX label
    if (!genderSet) {
      const labels = document.querySelectorAll('label');
      for (const label of labels) {
        const text = label.textContent.trim().toUpperCase().replace(/\*/g, '').trim();
        if (text === 'SEX' || text === 'GENDER') {
          const container = label.closest('div, fieldset, section') || label.parentElement;
          if (container) {
            const nearbyRadios = container.querySelectorAll('input[type="radio"]');
            console.log('Found', nearbyRadios.length, 'radios near SEX label');
            for (const radio of nearbyRadios) {
              const rLabel = document.querySelector(`label[for="${radio.id}"]`) || radio.closest('label');
              const rText = (rLabel?.textContent || radio.value || '').toLowerCase().trim();
              if (targetValues.some(tv => rText.includes(tv))) {
                console.log('Clicking radio near SEX label:', rText);
                radio.checked = true;
                radio.click();
                radio.dispatchEvent(new Event('change', { bubbles: true }));
                genderSet = true;
                break;
              }
            }
          }
          if (genderSet) break;
        }
      }
    }
    
    // Strategy 4: data-element
    if (!genderSet) {
      const sexEl = document.querySelector('[data-element="sex"]') || document.querySelector('[data-element="gender"]');
      if (sexEl) {
        if (sexEl.tagName === 'SELECT') {
          if (setDropdown(sexEl, patient.gender)) genderSet = true;
        } else {
          const radios = sexEl.querySelectorAll('input[type="radio"]');
          for (const radio of radios) {
            const rLabel = document.querySelector(`label[for="${radio.id}"]`) || radio.closest('label');
            const rText = (rLabel?.textContent || radio.value || '').toLowerCase();
            if (targetValues.some(tv => rText.includes(tv))) {
              radio.checked = true; radio.click();
              radio.dispatchEvent(new Event('change', { bubbles: true }));
              genderSet = true; break;
            }
          }
        }
      }
    }
    
    // Strategy 5: Click any matching short text near a SEX/GENDER label
    if (!genderSet) {
      const allEls = document.querySelectorAll('span, div, label, button, a');
      for (const el of allEls) {
        const text = el.textContent.trim().toLowerCase();
        if (text.length < 10 && targetValues.some(tv => text === tv)) {
          const nearLabel = el.closest('div, fieldset')?.querySelector('label');
          if (nearLabel && (nearLabel.textContent.toUpperCase().includes('SEX') || nearLabel.textContent.toUpperCase().includes('GENDER'))) {
            console.log('Clicking custom gender element:', text);
            el.click();
            genderSet = true; break;
          }
        }
      }
    }
    
    if (genderSet) {
      filled++;
      console.log('✓ Gender/Sex set to:', patient.gender);
    } else {
      console.log('⚠ Could not set gender/sex');
      notes.push('Sex may need manual selection');
      // Debug output
      console.log('DEBUG - All radios:');
      allRadios.forEach((r, i) => {
        const lbl = document.querySelector(`label[for="${r.id}"]`) || r.closest('label');
        console.log(`  Radio ${i}: value="${r.value}" name="${r.name}" id="${r.id}" label="${lbl?.textContent?.trim()}"`);
      });
    }
  }
  
  console.log(`✅ Filled ${filled} fields`);
  return { success: true, fieldsSet: filled, notes: notes.join('. ') };
}

// ============================================
// FILL APPOINTMENT
// ============================================
async function fillAppointment() {
  if (!selectedPatient) { showStatus('Please select a patient first', 'error'); return; }
  showStatus('Filling appointment...', 'info');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const patientName = `${selectedPatient.first_name} ${selectedPatient.last_name}`;
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (name) => {
        const fields = document.querySelectorAll('input[type="text"], input[placeholder*="patient" i], input[placeholder*="search" i]');
        for (const field of fields) {
          if (field.offsetParent !== null) {
            field.value = name;
            field.dispatchEvent(new Event('input', { bubbles: true }));
            field.dispatchEvent(new Event('change', { bubbles: true }));
            field.focus();
            return { success: true };
          }
        }
        return { success: false };
      },
      args: [patientName]
    });
    showStatus('✓ Appointment info filled!', 'success');
  } catch (error) {
    showStatus('Failed. Make sure appointment dialog is open.', 'error');
  }
}

// ============================================
// DAILY SCHEDULE
// ============================================
async function loadDailySchedule() {
  const dateStr = scheduleDate.value;
  if (!dateStr) return;
  scheduleSection.innerHTML = '<div class="no-results">Loading schedule...</div>';
  try {
    const startOfDay = new Date(dateStr + 'T00:00:00');
    const endOfDay = new Date(dateStr + 'T23:59:59');
    const url = `https://services.leadconnectorhq.com/calendars/events?locationId=${GHL_LOCATION_ID}&startTime=${startOfDay.toISOString()}&endTime=${endOfDay.toISOString()}`;
    const response = await fetch(url, { headers: { 'Authorization': `Bearer ${GHL_API_KEY}`, 'Version': '2021-07-28' } });
    if (!response.ok) { scheduleSection.innerHTML = '<div class="no-results">Failed to load schedule</div>'; return; }
    const data = await response.json();
    const events = data.events || [];
    scheduleSummary.innerHTML = `<div style="font-size:12px;color:#64748b;margin-bottom:8px;">${events.length} appointment(s) on ${new Date(dateStr + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}</div>`;
    if (events.length === 0) { scheduleSection.innerHTML = '<div class="no-results">No appointments scheduled</div>'; return; }
    events.sort((a, b) => new Date(a.startTime) - new Date(b.startTime));
    scheduleSection.innerHTML = '';
    events.forEach(event => {
      const startTime = new Date(event.startTime);
      const el = document.createElement('div');
      el.className = 'schedule-item';
      el.innerHTML = `
        <div class="schedule-time">${startTime.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>
        <div class="schedule-patient">${event.title || event.contactName || 'Unknown'}</div>
        <div class="schedule-type">${event.calendarName || ''} • ${event.status || ''}</div>
      `;
      scheduleSection.appendChild(el);
    });
  } catch (error) {
    scheduleSection.innerHTML = `<div class="no-results">Error: ${error.message}</div>`;
  }
}

function changeDate(days) {
  currentScheduleDate.setDate(currentScheduleDate.getDate() + days);
  scheduleDate.value = formatDateForInput(currentScheduleDate);
  loadDailySchedule();
}

// ============================================
// UTILITIES
// ============================================
function showStatus(message, type) {
  if (!message) { statusEl.style.display = 'none'; return; }
  statusEl.textContent = message;
  statusEl.className = `status ${type}`;
  statusEl.style.display = 'block';
}
function formatPhone(phone) {
  if (!phone) return '';
  const c = phone.replace(/\D/g, '');
  if (c.length === 10) return `(${c.slice(0,3)}) ${c.slice(3,6)}-${c.slice(6)}`;
  if (c.length === 11 && c[0] === '1') return `(${c.slice(1,4)}) ${c.slice(4,7)}-${c.slice(7)}`;
  return phone;
}
function formatDate(dateStr) {
  if (!dateStr) return '';
  if (dateStr.includes('-')) { const [y, m, d] = dateStr.split('-'); return `${m}/${d}/${y}`; }
  return dateStr;
}
function formatDateForInput(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}
