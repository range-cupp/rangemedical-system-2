// ============================================
// RANGE MEDICAL - PRACTICE FUSION EXTENSION
// Side Panel Script v1.3.0
// ============================================

// Configuration
const SUPABASE_URL = 'https://teivfptpozltpqwahgdl.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRlaXZmcHRwb3psdHBxd2FoZ2RsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ3MTMxNDksImV4cCI6MjA4MDI4OTE0OX0.NrI1AykMBOh91mM9BFvpSH0JwzGrkv5ADDkZinh0elc';
const GHL_API_KEY = 'pit-3077d6b0-6f08-4cb6-b74e-be7dd765e91d';
const GHL_LOCATION_ID = 'WICdvbXmTjQORW6GiHWW';
const UPDATE_URL = 'https://app.range-medical.com/api/extension/version';
const DOWNLOAD_URL = 'https://app.range-medical.com/api/extension/download';
const CURRENT_VERSION = '1.3.1';

// State
let selectedPatient = null;
let selectedAppointment = null;
let searchTimeout = null;

// DOM elements
const searchInput = document.getElementById('searchInput');
const statusEl = document.getElementById('status');
const patientList = document.getElementById('patientList');
const appointmentsSection = document.getElementById('appointmentsSection');
const appointmentsList = document.getElementById('appointmentsList');
const documentsSection = document.getElementById('documentsSection');
const documentsList = document.getElementById('documentsList');
const actionsSection = document.getElementById('actionsSection');
const fillDemoBtn = document.getElementById('fillDemoBtn');
const fillApptBtn = document.getElementById('fillApptBtn');
const pageIndicator = document.getElementById('pageIndicator');

// ============================================
// INITIALIZATION
// ============================================
document.addEventListener('DOMContentLoaded', () => {
  searchInput.addEventListener('input', handleSearch);
  fillDemoBtn.addEventListener('click', fillDemographics);
  fillApptBtn.addEventListener('click', fillAppointment);
  
  checkCurrentPage();
  checkForUpdates();
});

// ============================================
// UPDATE CHECKING
// ============================================
async function checkForUpdates() {
  try {
    const response = await fetch(UPDATE_URL);
    if (!response.ok) return;
    const data = await response.json();
    if (data.version && isNewerVersion(data.version, CURRENT_VERSION)) {
      showUpdateBanner(data.version, data.notes || 'Bug fixes and improvements');
    }
  } catch (e) {
    console.log('Update check failed:', e);
  }
}

function isNewerVersion(remote, local) {
  const remoteParts = remote.split('.').map(Number);
  const localParts = local.split('.').map(Number);
  for (let i = 0; i < Math.max(remoteParts.length, localParts.length); i++) {
    const r = remoteParts[i] || 0;
    const l = localParts[i] || 0;
    if (r > l) return true;
    if (r < l) return false;
  }
  return false;
}

function showUpdateBanner(newVersion, notes) {
  const banner = document.createElement('div');
  banner.id = 'updateBanner';
  banner.innerHTML = `
    <div style="background:linear-gradient(135deg,#0ea5e9,#0284c7);color:white;padding:12px 16px;border-radius:10px;margin-bottom:16px;">
      <div style="font-weight:600;margin-bottom:4px;">🎉 Update Available (v${newVersion})</div>
      <div style="font-size:12px;opacity:0.9;margin-bottom:10px;">${notes}</div>
      <button id="downloadUpdate" style="background:white;color:#0284c7;border:none;padding:8px 16px;border-radius:6px;font-weight:500;cursor:pointer;font-size:13px;">Download Update</button>
      <button id="dismissUpdate" style="background:transparent;color:white;border:1px solid rgba(255,255,255,0.3);padding:8px 12px;border-radius:6px;margin-left:8px;cursor:pointer;font-size:13px;">Later</button>
    </div>
  `;
  const container = document.querySelector('.container');
  container.insertBefore(banner, container.children[1]);
  document.getElementById('downloadUpdate').addEventListener('click', () => window.open(DOWNLOAD_URL, '_blank'));
  document.getElementById('dismissUpdate').addEventListener('click', () => banner.remove());
}

// ============================================
// PAGE DETECTION
// ============================================
async function checkCurrentPage() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url) return;
    const url = tab.url;
    if (url.includes('charts/patients/add')) {
      pageIndicator.textContent = '📝 Ready to fill patient demographics';
      pageIndicator.style.display = 'block';
    } else if (url.includes('/schedule')) {
      pageIndicator.textContent = '📅 Ready to fill appointment';
      pageIndicator.style.display = 'block';
    } else if (url.includes('/charts/') && url.includes('/documents')) {
      pageIndicator.textContent = '📄 Ready to upload documents';
      pageIndicator.style.display = 'block';
    } else if (url.includes('practicefusion.com')) {
      pageIndicator.style.display = 'none';
    } else {
      pageIndicator.textContent = '⚠️ Open Practice Fusion to use this extension';
      pageIndicator.style.display = 'block';
      pageIndicator.style.background = '#fef2f2';
      pageIndicator.style.color = '#dc2626';
    }
  } catch (e) {
    console.log('Page check error:', e);
  }
}

// ============================================
// SEARCH - Both intakes AND ghl_contacts
// ============================================
function handleSearch() {
  clearTimeout(searchTimeout);
  const query = searchInput.value.trim();
  if (query.length < 2) {
    patientList.innerHTML = '';
    actionsSection.style.display = 'none';
    appointmentsSection.style.display = 'none';
    documentsSection.style.display = 'none';
    return;
  }
  searchTimeout = setTimeout(() => searchPatients(query), 300);
}

async function searchPatients(query) {
  showStatus('Searching...', 'info');
  try {
    const cleanQuery = query.trim();
    const cleanDigits = cleanQuery.replace(/\D/g, '');
    const isPhoneSearch = cleanDigits.length >= 7;
    
    let intakeResults = [];
    let ghlResults = [];
    
    let intakeUrl = `${SUPABASE_URL}/rest/v1/intakes?select=*`;
    let ghlUrl = `${SUPABASE_URL}/rest/v1/ghl_contacts?select=*`;
    
    if (isPhoneSearch) {
      const phoneSearch = cleanDigits.slice(-7);
      intakeUrl += `&phone=ilike.*${phoneSearch}*`;
      ghlUrl += `&phone=ilike.*${phoneSearch}*`;
    } else {
      const nameParts = cleanQuery.toLowerCase().split(' ').filter(p => p.length > 0);
      if (nameParts.length >= 2) {
        intakeUrl += `&first_name=ilike.*${nameParts[0]}*&last_name=ilike.*${nameParts[1]}*`;
        ghlUrl += `&first_name=ilike.*${nameParts[0]}*&last_name=ilike.*${nameParts[1]}*`;
      } else {
        intakeUrl += `&or=(first_name.ilike.*${nameParts[0]}*,last_name.ilike.*${nameParts[0]}*)`;
        ghlUrl += `&or=(first_name.ilike.*${nameParts[0]}*,last_name.ilike.*${nameParts[0]}*)`;
      }
    }
    
    intakeUrl += '&order=created_at.desc&limit=15';
    ghlUrl += '&order=updated_at.desc&limit=15';
    
    const intakeResponse = await fetch(intakeUrl, {
      headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` }
    });
    if (intakeResponse.ok) {
      intakeResults = await intakeResponse.json();
      intakeResults = intakeResults.map(p => ({ ...p, _source: 'intake' }));
    }
    
    const ghlResponse = await fetch(ghlUrl, {
      headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` }
    });
    if (ghlResponse.ok) {
      ghlResults = await ghlResponse.json();
      ghlResults = ghlResults.map(p => ({ ...p, _source: 'ghl' }));
    }
    
    // Merge results, preferring intake records
    const seenPhones = new Set();
    const seenEmails = new Set();
    const patients = [];
    
    for (const patient of intakeResults) {
      const phone = (patient.phone || '').replace(/\D/g, '').slice(-10);
      const email = (patient.email || '').toLowerCase();
      if (phone) seenPhones.add(phone);
      if (email) seenEmails.add(email);
      patients.push(patient);
    }
    
    for (const patient of ghlResults) {
      const phone = (patient.phone || '').replace(/\D/g, '').slice(-10);
      const email = (patient.email || '').toLowerCase();
      if (phone && seenPhones.has(phone)) continue;
      if (email && seenEmails.has(email)) continue;
      if (phone) seenPhones.add(phone);
      if (email) seenEmails.add(email);
      patients.push(patient);
    }
    
    console.log(`Search results: ${intakeResults.length} intakes, ${ghlResults.length} GHL, ${patients.length} merged`);
    
    if (patients.length === 0) {
      patientList.innerHTML = '<div class="no-results">No patients found</div>';
      showStatus('', '');
      return;
    }
    
    displayPatients(patients);
    showStatus('', '');
  } catch (error) {
    console.error('Search error:', error);
    showStatus('Search failed. Please try again.', 'error');
  }
}

function displayPatients(patients) {
  patientList.innerHTML = patients.map(p => {
    const isGHL = p._source === 'ghl';
    const badge = isGHL ? '<span style="background:#f97316;color:white;padding:2px 6px;border-radius:4px;font-size:10px;margin-left:8px;">GHL</span>' : '';
    return `
      <div class="patient-card" data-id="${p.id}" data-source="${p._source}">
        <div class="patient-name">${p.first_name} ${p.last_name}${badge}</div>
        <div class="patient-info">
          <span>📞 ${formatPhone(p.phone)}</span>
          ${p.date_of_birth ? `<span>🎂 ${formatDate(p.date_of_birth)}</span>` : ''}
          ${p.email ? `<span>✉️ ${p.email}</span>` : ''}
        </div>
      </div>
    `;
  }).join('');
  
  patientList._patients = patients;
  
  patientList.querySelectorAll('.patient-card').forEach(card => {
    card.addEventListener('click', () => {
      const id = card.dataset.id;
      const patient = patients.find(p => p.id === id);
      if (patient) selectPatient(patient);
    });
  });
}

async function selectPatient(patient) {
  patientList.querySelectorAll('.patient-card').forEach(c => c.classList.remove('selected'));
  const card = patientList.querySelector(`[data-id="${patient.id}"]`);
  if (card) card.classList.add('selected');
  
  showStatus('Loading patient data...', 'info');
  
  // Fetch documents
  patient.documents = await fetchPatientDocuments(
    patient.id, patient.phone, patient.email,
    patient.first_name?.trim(), patient.last_name?.trim(),
    patient.pdf_url, patient.photo_id_url
  );
  
  // Fetch appointments
  if (patient.ghl_contact_id) {
    console.log(`📅 Fetching appointments using GHL ID: ${patient.ghl_contact_id}`);
    patient.appointments = await fetchAppointmentsForContact(patient.ghl_contact_id);
  } else if (patient.phone) {
    console.log(`📅 Fetching appointments using phone: ${patient.phone}`);
    const ghlContactId = await findGHLContactId(patient.phone, patient.email);
    if (ghlContactId) {
      console.log(`📅 Found GHL contact ID: ${ghlContactId}`);
      patient.appointments = await fetchAppointmentsForContact(ghlContactId);
    } else {
      patient.appointments = [];
    }
  } else {
    patient.appointments = [];
  }
  console.log(`📅 ${patient.first_name} has ${patient.appointments?.length || 0} appointments`);
  
  selectedPatient = patient;
  selectedAppointment = null;
  
  // Display documents with download buttons
  if (patient.documents?.length > 0) {
    documentsSection.style.display = 'block';
    
    // Add Download All button at the top
    const downloadAllBtn = `
      <button id="downloadAllBtn" class="download-all-btn">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
          <polyline points="7 10 12 15 17 10"/>
          <line x1="12" y1="15" x2="12" y2="3"/>
        </svg>
        Download All (${patient.documents.length})
      </button>
    `;
    
    documentsList.innerHTML = downloadAllBtn + patient.documents.map(doc => {
      const isImage = doc.isImage || doc.url?.match(/\.(png|jpg|jpeg|gif|webp)$/i) || doc.url?.includes('/photo-ids/');
      const iconColor = isImage ? '#2563eb' : '#dc2626';
      const iconBg = isImage ? '#dbeafe' : '#fee2e2';
      const icon = isImage 
        ? `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="${iconColor}" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>`
        : `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="${iconColor}" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>`;
      
      const safeName = `${patient.first_name}_${patient.last_name}`.replace(/[^a-zA-Z0-9]/g, '_');
      const docType = doc.type.replace(/[^a-zA-Z0-9]/g, '_');
      const ext = isImage ? (doc.url?.match(/\.(png|jpg|jpeg|gif|webp)$/i)?.[1] || 'png') : 'pdf';
      const fileName = `${safeName}_${docType}.${ext}`;
      
      return `
        <div class="doc-item">
          <div style="display:flex;align-items:center;gap:8px;flex:1;">
            <div style="background:${iconBg};padding:6px;border-radius:6px;display:flex;">${icon}</div>
            <div>
              <div class="doc-name">${doc.type}</div>
              <div style="font-size:10px;color:#94a3b8;">${fileName}</div>
            </div>
          </div>
          <button class="download-btn" data-url="${doc.url}" data-filename="${fileName}">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="7 10 12 15 17 10"/>
              <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
            Download
          </button>
        </div>
      `;
    }).join('');
    
    // Add download handlers
    documentsList.querySelectorAll('.download-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const url = btn.dataset.url;
        const filename = btn.dataset.filename;
        btn.textContent = 'Downloading...';
        btn.disabled = true;
        try {
          const response = await fetch(url);
          const blob = await response.blob();
          const blobUrl = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = blobUrl;
          a.download = filename;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(blobUrl);
          btn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg> Done`;
          setTimeout(() => {
            btn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Download`;
            btn.disabled = false;
          }, 2000);
        } catch (err) {
          console.error('Download failed:', err);
          btn.textContent = 'Failed';
          btn.disabled = false;
        }
      });
    });
    
    // Add Download All handler
    const downloadAllBtnEl = document.getElementById('downloadAllBtn');
    if (downloadAllBtnEl) {
      downloadAllBtnEl.addEventListener('click', async () => {
        const allBtns = documentsList.querySelectorAll('.download-btn');
        downloadAllBtnEl.textContent = 'Downloading...';
        downloadAllBtnEl.disabled = true;
        
        for (const btn of allBtns) {
          const url = btn.dataset.url;
          const filename = btn.dataset.filename;
          try {
            const response = await fetch(url);
            const blob = await response.blob();
            const blobUrl = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = blobUrl;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(blobUrl);
            // Small delay between downloads
            await new Promise(r => setTimeout(r, 300));
          } catch (err) {
            console.error('Download failed:', err);
          }
        }
        
        downloadAllBtnEl.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg> All Downloaded!`;
        setTimeout(() => {
          downloadAllBtnEl.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Download All (${patient.documents.length})`;
          downloadAllBtnEl.disabled = false;
        }, 2000);
      });
    }
  } else {
    documentsSection.style.display = 'none';
  }
  
  // Display appointments
  if (patient.appointments?.length > 0) {
    appointmentsSection.style.display = 'block';
    appointmentsList.innerHTML = patient.appointments.map(appt => {
      const isPast = appt.isPast;
      const statusColor = isPast ? '#94a3b8' : '#16a34a';
      const statusText = isPast ? 'Past' : 'Upcoming';
      return `
        <div class="appointment-item ${selectedAppointment?.id === appt.id ? 'selected' : ''}" data-id="${appt.id}">
          <div class="appointment-date">${appt.date} at ${appt.time}</div>
          <div class="appointment-type">${appt.title}</div>
          <div style="font-size:11px;color:${statusColor};margin-top:4px;">${statusText}</div>
        </div>
      `;
    }).join('');
    
    appointmentsList.querySelectorAll('.appointment-item').forEach(item => {
      item.addEventListener('click', () => {
        appointmentsList.querySelectorAll('.appointment-item').forEach(i => i.classList.remove('selected'));
        item.classList.add('selected');
        selectedAppointment = patient.appointments.find(a => a.id === item.dataset.id);
      });
    });
  } else {
    appointmentsSection.style.display = 'none';
  }
  
  actionsSection.style.display = 'flex';
  showStatus('', '');
}

// ============================================
// FETCH DOCUMENTS
// ============================================
async function fetchPatientDocuments(patientId, phone, email, firstName, lastName, pdfUrl, photoIdUrl) {
  const allDocs = [];
  firstName = firstName?.trim();
  lastName = lastName?.trim();
  console.log('🔍 Fetching documents for:', { patientId, phone, email, firstName, lastName });
  
  if (pdfUrl) {
    allDocs.push({ type: 'Medical Intake Form', url: pdfUrl });
  }
  if (photoIdUrl) {
    allDocs.push({ type: "Driver's License / Photo ID", url: photoIdUrl, isImage: true });
  }
  
  if (patientId && !pdfUrl) {
    try {
      const intakeUrl = `${SUPABASE_URL}/rest/v1/intakes?id=eq.${patientId}&select=pdf_url,photo_id_url`;
      const intakeRes = await fetch(intakeUrl, {
        headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` }
      });
      const intakes = await intakeRes.json();
      if (intakes?.[0]?.pdf_url) allDocs.push({ type: 'Medical Intake Form', url: intakes[0].pdf_url });
      if (intakes?.[0]?.photo_id_url) allDocs.push({ type: "Driver's License / Photo ID", url: intakes[0].photo_id_url, isImage: true });
    } catch (e) { console.log('Intake fetch error:', e); }
  }
  
  // Fetch consents
  try {
    if (phone) {
      const cleanPhone = phone.replace(/\D/g, '');
      const consentsUrl = `${SUPABASE_URL}/rest/v1/consents?phone=ilike.*${cleanPhone.slice(-7)}*&select=consent_type,pdf_url`;
      const consentsRes = await fetch(consentsUrl, {
        headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` }
      });
      const consents = await consentsRes.json();
      console.log('Found consents by phone:', consents?.length || 0);
      consents?.forEach(c => {
        if (c.pdf_url && !allDocs.find(d => d.url === c.pdf_url)) {
          allDocs.push({ type: c.consent_type || 'Consent Form', url: c.pdf_url });
        }
      });
    }
    
    if (allDocs.length <= 2 && email) {
      const emailUrl = `${SUPABASE_URL}/rest/v1/consents?email=ilike.${encodeURIComponent(email)}&select=consent_type,pdf_url`;
      const emailRes = await fetch(emailUrl, {
        headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` }
      });
      const emailConsents = await emailRes.json();
      emailConsents?.forEach(c => {
        if (c.pdf_url && !allDocs.find(d => d.url === c.pdf_url)) {
          allDocs.push({ type: c.consent_type || 'Consent Form', url: c.pdf_url });
        }
      });
    }
    
    if (allDocs.length <= 2 && firstName && lastName) {
      const nameUrl = `${SUPABASE_URL}/rest/v1/consents?first_name=ilike.${encodeURIComponent(firstName)}&last_name=ilike.${encodeURIComponent(lastName)}&select=consent_type,pdf_url`;
      const nameRes = await fetch(nameUrl, {
        headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` }
      });
      const nameConsents = await nameRes.json();
      nameConsents?.forEach(c => {
        if (c.pdf_url && !allDocs.find(d => d.url === c.pdf_url)) {
          allDocs.push({ type: c.consent_type || 'Consent Form', url: c.pdf_url });
        }
      });
    }
  } catch (e) { console.log('Consents fetch error:', e); }
  
  console.log('✅ Final document count:', allDocs.length);
  return allDocs;
}

// ============================================
// GHL APPOINTMENTS
// ============================================
async function findGHLContactId(phone, email) {
  try {
    const cleanPhone = phone?.replace(/\D/g, '') || '';
    const last7 = cleanPhone.slice(-7);
    
    if (last7) {
      const phoneUrl = `${SUPABASE_URL}/rest/v1/ghl_contacts?phone=ilike.*${last7}*&select=ghl_contact_id&limit=1`;
      const phoneResponse = await fetch(phoneUrl, {
        headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` }
      });
      if (phoneResponse.ok) {
        const results = await phoneResponse.json();
        if (results.length > 0 && results[0].ghl_contact_id) return results[0].ghl_contact_id;
      }
    }
    
    if (email) {
      const emailUrl = `${SUPABASE_URL}/rest/v1/ghl_contacts?email=ilike.${encodeURIComponent(email)}&select=ghl_contact_id&limit=1`;
      const emailResponse = await fetch(emailUrl, {
        headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` }
      });
      if (emailResponse.ok) {
        const results = await emailResponse.json();
        if (results.length > 0 && results[0].ghl_contact_id) return results[0].ghl_contact_id;
      }
    }
    return null;
  } catch (error) {
    console.error('Error finding GHL contact ID:', error);
    return null;
  }
}

async function fetchAppointmentsForContact(contactId) {
  try {
    const now = new Date();
    const appointmentsUrl = `https://services.leadconnectorhq.com/contacts/${contactId}/appointments`;
    console.log('Fetching contact appointments:', appointmentsUrl);
    
    const response = await fetch(appointmentsUrl, {
      headers: {
        'Authorization': `Bearer ${GHL_API_KEY}`,
        'Version': '2021-07-28',
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      console.log('GHL appointments fetch failed:', response.status);
      return [];
    }
    
    const data = await response.json();
    console.log('Raw appointment response:', data);
    const events = data.events || [];
    console.log('Found appointments:', events.length);
    
    const pastDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const futureDate = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
    
    return events.map(event => {
      const eventDate = new Date(event.startTime);
      return {
        id: event.id,
        title: event.title || 'Appointment',
        date: eventDate.toLocaleDateString('en-US'),
        time: eventDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }),
        startTime: event.startTime,
        isPast: eventDate < now
      };
    })
    .filter(a => {
      const d = new Date(a.startTime);
      return d >= pastDate && d <= futureDate;
    })
    .sort((a, b) => new Date(a.startTime) - new Date(b.startTime));
  } catch (error) {
    console.error('Error fetching appointments:', error);
    return [];
  }
}

// ============================================
// ACTIONS - FILL DEMOGRAPHICS
// ============================================
async function fillDemographics() {
  if (!selectedPatient) {
    showStatus('Please select a patient first', 'error');
    return;
  }
  showStatus('Filling demographics...', 'info');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const patient = {
    firstName: selectedPatient.first_name?.trim(),
    lastName: selectedPatient.last_name?.trim(),
    email: selectedPatient.email,
    phone: selectedPatient.phone,
    dob: selectedPatient.date_of_birth,
    gender: selectedPatient.gender,
    address: selectedPatient.street_address,
    city: selectedPatient.city,
    state: selectedPatient.state,
    zip: selectedPatient.postal_code
  };
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: fillPFDemographics,
      args: [patient]
    });
    showStatus('✓ Demographics filled!', 'success');
  } catch (error) {
    console.error('Fill error:', error);
    showStatus('Failed to fill. Make sure you\'re on the Add Patient page.', 'error');
  }
}

function fillPFDemographics(patient) {
  console.log('🏥 Filling demographics for:', patient);
  function findByLabel(labelText) {
    const labels = document.querySelectorAll('label');
    for (const label of labels) {
      if (label.textContent.toUpperCase().includes(labelText.toUpperCase())) {
        const forId = label.getAttribute('for');
        if (forId) return document.getElementById(forId);
        const input = label.querySelector('input, select');
        if (input) return input;
        const next = label.nextElementSibling;
        if (next?.tagName === 'INPUT' || next?.tagName === 'SELECT') return next;
      }
    }
    return null;
  }
  function findByDataElement(elementName) {
    return document.querySelector(`[data-element="${elementName}"]`);
  }
  function setVal(el, val) {
    if (!el || !val) return false;
    el.value = val;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  }
  let filled = 0;
  if (setVal(findByDataElement('first-name') || findByLabel('FIRST'), patient.firstName)) filled++;
  if (setVal(findByDataElement('last-name') || findByLabel('LAST'), patient.lastName)) filled++;
  if (setVal(findByDataElement('email-address') || findByLabel('EMAIL'), patient.email)) filled++;
  if (setVal(findByDataElement('mobile-phone') || findByLabel('MOBILE'), patient.phone?.replace(/\D/g, ''))) filled++;
  if (setVal(findByDataElement('address-line1') || findByLabel('ADDRESS LINE 1'), patient.address)) filled++;
  if (setVal(findByDataElement('city') || findByLabel('CITY'), patient.city)) filled++;
  if (setVal(findByDataElement('zip') || findByLabel('ZIP'), patient.zip)) filled++;
  if (patient.dob) {
    const dobField = findByDataElement('date-of-birth') || findByLabel('DATE OF BIRTH') || findByLabel('DOB');
    if (dobField) {
      const [year, month, day] = patient.dob.split('-');
      if (setVal(dobField, `${month}/${day}/${year}`)) filled++;
    }
  }
  const stateField = findByDataElement('state') || findByLabel('STATE');
  if (stateField && patient.state) {
    if (stateField.tagName === 'SELECT') {
      const options = stateField.querySelectorAll('option');
      for (const opt of options) {
        if (opt.textContent.toLowerCase().includes(patient.state.toLowerCase()) || opt.value.toLowerCase() === patient.state.toLowerCase()) {
          stateField.value = opt.value;
          stateField.dispatchEvent(new Event('change', { bubbles: true }));
          filled++;
          break;
        }
      }
    } else {
      setVal(stateField, patient.state);
      filled++;
    }
  }
  if (patient.gender) {
    const radios = document.querySelectorAll(`input[type="radio"]`);
    for (const radio of radios) {
      const label = radio.closest('label') || document.querySelector(`label[for="${radio.id}"]`);
      if (label?.textContent.toLowerCase().includes(patient.gender.toLowerCase())) {
        radio.click();
        filled++;
        break;
      }
    }
  }
  console.log(`✅ Filled ${filled} fields`);
  return { success: true, fieldsSet: filled };
}

// ============================================
// ACTIONS - FILL APPOINTMENT
// ============================================
async function fillAppointment() {
  if (!selectedPatient) {
    showStatus('Please select a patient first', 'error');
    return;
  }
  showStatus('Filling appointment...', 'info');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const patientName = `${selectedPatient.first_name} ${selectedPatient.last_name}`;
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: fillPFAppointment,
      args: [patientName]
    });
    showStatus('✓ Appointment info filled!', 'success');
  } catch (error) {
    console.error('Appointment fill error:', error);
    showStatus('Failed to fill. Make sure appointment dialog is open.', 'error');
  }
}

function fillPFAppointment(patientName) {
  console.log('🏥 Filling appointment for:', patientName);
  const searchFields = document.querySelectorAll('input[type="text"], input[placeholder*="patient" i], input[placeholder*="search" i]');
  for (const field of searchFields) {
    if (field.offsetParent !== null) {
      field.value = patientName;
      field.dispatchEvent(new Event('input', { bubbles: true }));
      field.dispatchEvent(new Event('change', { bubbles: true }));
      field.focus();
      console.log('✅ Filled patient search field');
      break;
    }
  }
  return { success: true };
}

// ============================================
// UTILITIES
// ============================================
function showStatus(message, type) {
  if (!message) { statusEl.style.display = 'none'; return; }
  statusEl.textContent = message;
  statusEl.className = `status ${type}`;
}

function formatPhone(phone) {
  if (!phone) return '';
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.length === 10) return `(${cleaned.slice(0,3)}) ${cleaned.slice(3,6)}-${cleaned.slice(6)}`;
  return phone;
}

function formatDate(dateStr) {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-');
  return `${month}/${day}/${year}`;
}
