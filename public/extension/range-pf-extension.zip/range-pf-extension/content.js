// ============================================
// RANGE MEDICAL - PRACTICE FUSION EXTENSION
// Content Script v1.2.1
// ============================================

console.log('🏥 Range Medical extension loaded on Practice Fusion');

// Listen for messages from popup/sidepanel
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Content script received:', request);
  
  if (request.action === 'fillDemographics') {
    const result = fillDemographics(request.patient);
    sendResponse(result);
  }
  
  if (request.action === 'fillAppointment') {
    const result = fillAppointment(request.patientName);
    sendResponse(result);
  }
  
  if (request.action === 'showDocuments') {
    showDocumentPanel(request.documents, request.patientName);
    sendResponse({ success: true });
  }
  
  return true;
});

// Fill demographics function (backup if scripting fails)
function fillDemographics(patient) {
  console.log('🏥 Filling demographics for:', patient);
  
  function findByLabel(labelText) {
    const labels = document.querySelectorAll('label');
    for (const label of labels) {
      if (label.textContent.toUpperCase().includes(labelText.toUpperCase())) {
        const forId = label.getAttribute('for');
        if (forId) return document.getElementById(forId);
        const input = label.querySelector('input, select');
        if (input) return input;
        const next = label.nextElementSibling;
        if (next?.tagName === 'INPUT' || next?.tagName === 'SELECT') return next;
      }
    }
    return null;
  }
  
  function findByDataElement(elementName) {
    return document.querySelector(`[data-element="${elementName}"]`);
  }
  
  function setVal(el, val) {
    if (!el || !val) return false;
    el.value = val;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  }
  
  let filled = 0;
  
  if (setVal(findByDataElement('first-name') || findByLabel('FIRST'), patient.firstName)) filled++;
  if (setVal(findByDataElement('last-name') || findByLabel('LAST'), patient.lastName)) filled++;
  if (setVal(findByDataElement('email-address') || findByLabel('EMAIL'), patient.email)) filled++;
  if (setVal(findByDataElement('mobile-phone') || findByLabel('MOBILE'), patient.phone?.replace(/\D/g, ''))) filled++;
  if (setVal(findByDataElement('address-line1') || findByLabel('ADDRESS LINE 1'), patient.address)) filled++;
  if (setVal(findByDataElement('city') || findByLabel('CITY'), patient.city)) filled++;
  if (setVal(findByDataElement('zip') || findByLabel('ZIP'), patient.zip)) filled++;
  
  if (patient.dob) {
    const dobField = findByDataElement('date-of-birth') || findByLabel('DATE OF BIRTH') || findByLabel('DOB');
    if (dobField) {
      const [year, month, day] = patient.dob.split('-');
      const formatted = `${month}/${day}/${year}`;
      if (setVal(dobField, formatted)) filled++;
    }
  }
  
  const stateField = findByDataElement('state') || findByLabel('STATE');
  if (stateField && patient.state) {
    if (stateField.tagName === 'SELECT') {
      const options = stateField.querySelectorAll('option');
      for (const opt of options) {
        if (opt.textContent.toLowerCase().includes(patient.state.toLowerCase()) ||
            opt.value.toLowerCase() === patient.state.toLowerCase()) {
          stateField.value = opt.value;
          stateField.dispatchEvent(new Event('change', { bubbles: true }));
          filled++;
          break;
        }
      }
    } else {
      setVal(stateField, patient.state);
      filled++;
    }
  }
  
  if (patient.gender) {
    const radios = document.querySelectorAll(`input[type="radio"]`);
    for (const radio of radios) {
      const label = radio.closest('label') || document.querySelector(`label[for="${radio.id}"]`);
      if (label?.textContent.toLowerCase().includes(patient.gender.toLowerCase())) {
        radio.click();
        filled++;
        break;
      }
    }
  }
  
  console.log(`✅ Filled ${filled} fields`);
  return { success: true, fieldsSet: filled };
}

// Fill appointment function
function fillAppointment(patientName) {
  console.log('🏥 Filling appointment for:', patientName);
  
  const searchFields = document.querySelectorAll('input[type="text"], input[placeholder*="patient" i], input[placeholder*="search" i]');
  
  for (const field of searchFields) {
    if (field.offsetParent !== null) {
      field.value = patientName;
      field.dispatchEvent(new Event('input', { bubbles: true }));
      field.dispatchEvent(new Event('change', { bubbles: true }));
      field.focus();
      console.log('✅ Filled patient search field');
      return { success: true };
    }
  }
  
  console.log('❌ Could not find patient search field');
  return { success: false };
}

// Show document panel
function showDocumentPanel(docs, patientName) {
  const existing = document.getElementById('range-doc-panel');
  if (existing) existing.remove();
  
  const panel = document.createElement('div');
  panel.id = 'range-doc-panel';
  panel.innerHTML = `
    <div style="
      position: fixed;
      top: 20px;
      right: 20px;
      width: 320px;
      background: white;
      border-radius: 12px;
      box-shadow: 0 4px 24px rgba(0,0,0,0.15);
      z-index: 999999;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    ">
      <div style="
        padding: 16px;
        border-bottom: 1px solid #e2e8f0;
        display: flex;
        justify-content: space-between;
        align-items: center;
      ">
        <div>
          <div style="font-weight: 600; color: #0f172a;">Documents</div>
          <div style="font-size: 12px; color: #64748b;">${patientName}</div>
        </div>
        <button id="range-close-panel" style="
          background: none;
          border: none;
          font-size: 20px;
          cursor: pointer;
          color: #94a3b8;
          padding: 4px;
        ">×</button>
      </div>
      <div style="padding: 12px; max-height: 400px; overflow-y: auto;">
        ${docs.map(doc => `
          <div style="
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            background: #f8fafc;
            border-radius: 8px;
            margin-bottom: 8px;
          ">
            <div style="font-weight: 500; font-size: 13px; color: #0f172a;">${doc.type}</div>
            <a href="${doc.url}" target="_blank" style="
              padding: 8px 12px;
              background: #0ea5e9;
              color: white;
              text-decoration: none;
              border-radius: 6px;
              font-size: 12px;
            ">Open PDF</a>
          </div>
        `).join('')}
      </div>
    </div>
  `;
  
  document.body.appendChild(panel);
  document.getElementById('range-close-panel').addEventListener('click', () => panel.remove());
}
