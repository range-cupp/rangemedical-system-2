console.log('🏥 Range Medical extension loaded on Practice Fusion');
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'ping') sendResponse({ success: true });
});
