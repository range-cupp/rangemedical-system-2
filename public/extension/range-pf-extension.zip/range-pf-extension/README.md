# Range Medical → Practice Fusion Extension

**Version 1.2.2** - Chrome extension to auto-fill patient data from Range Medical into Practice Fusion.

## Features

1. **Search Patients** - Search your Supabase database by name or phone number
2. **Fill Demographics** - One-click auto-fill of patient demographics on Practice Fusion's Add Patient page
3. **Upload Documents** - Quick access to intake forms and consent PDFs for uploading to patient charts
4. **Fill Appointments** - Auto-populate patient info when creating appointments
5. **Auto-Update Notifications** - Get notified when a new version is available

## Installation

### Step 1: Download the Extension
Download and unzip the `range-pf-extension.zip` file to a folder on your computer (e.g., `Documents/range-pf-extension`).

**Important:** Remember this location - you'll need it for updates!

### Step 2: Open Chrome Extensions
1. Open Chrome
2. Go to `chrome://extensions/` in the address bar
3. Enable **Developer mode** (toggle in the top right corner)

### Step 3: Load the Extension
1. Click **Load unpacked**
2. Select the `range-pf-extension` folder you unzipped
3. The extension should now appear in your extensions list

### Step 4: Pin the Extension
1. Click the puzzle piece icon in Chrome's toolbar
2. Find "Range Medical → Practice Fusion"
3. Click the pin icon to keep it visible

## Updating the Extension

When a new version is available, you'll see a blue banner in the extension:

1. Click **Download Update**
2. Unzip the new file to the **same folder** as before (replace old files)
3. Go to `chrome://extensions/`
4. Click the **refresh icon** (🔄) on the Range Medical extension
5. Done! You're now on the latest version

## How to Use

### Side Panel
Click the extension icon to open a side panel that stays open as you navigate Practice Fusion.

### Filling Patient Demographics

1. In Practice Fusion, go to **Patient Lists** → **Add Patient**
2. Click the Range Medical extension icon (opens side panel)
3. Search for the patient by name or phone number
4. Click on the patient card to select them
5. Click **Fill Demographics**
6. The form will auto-populate with the patient's information
7. Review and click **Save** in Practice Fusion

### Uploading Documents

1. In Practice Fusion, open the patient's chart
2. Go to the **Documents** tab
3. Click the Range Medical extension icon
4. Search and select the patient
5. Click **Upload Documents**
6. A panel will appear with links to all available documents
7. Click each document to open it, then upload to Practice Fusion

### Creating Appointments

1. In Practice Fusion, go to **Schedule**
2. Click **Add appointment**
3. Click the Range Medical extension icon
4. Search and select the patient
5. Click **Fill Appointment**
6. The patient search field will be populated

## Field Mapping

| Range Medical Field | Practice Fusion Field |
|--------------------|----------------------|
| first_name | FIRST |
| last_name | LAST |
| email | EMAIL |
| date_of_birth | DATE OF BIRTH |
| gender | SEX |
| phone | MOBILE |
| street_address | ADDRESS LINE 1 |
| city | CITY |
| state | STATE |
| postal_code | ZIP |

## Troubleshooting

### Extension not working?
- Make sure you're on a Practice Fusion page (static.practicefusion.com)
- Try refreshing the Practice Fusion page
- Check that the extension is enabled in `chrome://extensions/`

### Demographics not filling?
- Make sure you're on the Add Patient page
- The page indicator in the extension should show "Ready to fill patient demographics"

### Search not finding patients?
- Try searching by phone number (last 7 digits work)
- Try searching by first and last name together
- Make sure the patient has completed an intake form in Range Medical

## Support

For issues or questions, contact Range Medical support.

---
Built for Range Medical © 2026
