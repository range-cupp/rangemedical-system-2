// ============================================
// RANGE MEDICAL - PRACTICE FUSION EXTENSION
// Side Panel Script v1.2.2
// ============================================

// Configuration
const SUPABASE_URL = 'https://teivfptpozltpqwahgdl.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRlaXZmcHRwb3psdHBxd2FoZ2RsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ3MTMxNDksImV4cCI6MjA4MDI4OTE0OX0.NrI1AykMBOh91mM9BFvpSH0JwzGrkv5ADDkZinh0elc';
const UPDATE_URL = 'https://app.range-medical.com/api/extension/version';
const DOWNLOAD_URL = 'https://app.range-medical.com/api/extension/download';
const CURRENT_VERSION = '1.2.5';

// State
let selectedPatient = null;
let selectedAppointment = null;
let searchTimeout = null;

// DOM elements
const searchInput = document.getElementById('searchInput');
const statusEl = document.getElementById('status');
const patientList = document.getElementById('patientList');
const appointmentsSection = document.getElementById('appointmentsSection');
const appointmentsList = document.getElementById('appointmentsList');
const documentsSection = document.getElementById('documentsSection');
const documentsList = document.getElementById('documentsList');
const actionsSection = document.getElementById('actionsSection');
const fillDemoBtn = document.getElementById('fillDemoBtn');
const fillApptBtn = document.getElementById('fillApptBtn');
const pageIndicator = document.getElementById('pageIndicator');

// ============================================
// INITIALIZATION
// ============================================
document.addEventListener('DOMContentLoaded', () => {
  searchInput.addEventListener('input', handleSearch);
  fillDemoBtn.addEventListener('click', fillDemographics);
  fillApptBtn.addEventListener('click', fillAppointment);
  
  checkCurrentPage();
  checkForUpdates();
});

// ============================================
// UPDATE CHECKING
// ============================================
async function checkForUpdates() {
  try {
    const response = await fetch(UPDATE_URL);
    if (!response.ok) return;
    
    const data = await response.json();
    
    if (data.version && isNewerVersion(data.version, CURRENT_VERSION)) {
      showUpdateBanner(data.version, data.notes || 'Bug fixes and improvements');
    }
  } catch (e) {
    console.log('Update check failed:', e);
  }
}

function isNewerVersion(remote, local) {
  const remoteParts = remote.split('.').map(Number);
  const localParts = local.split('.').map(Number);
  
  for (let i = 0; i < Math.max(remoteParts.length, localParts.length); i++) {
    const r = remoteParts[i] || 0;
    const l = localParts[i] || 0;
    if (r > l) return true;
    if (r < l) return false;
  }
  return false;
}

function showUpdateBanner(newVersion, notes) {
  const banner = document.createElement('div');
  banner.id = 'updateBanner';
  banner.innerHTML = `
    <div style="
      background: linear-gradient(135deg, #0ea5e9, #0284c7);
      color: white;
      padding: 12px 16px;
      border-radius: 10px;
      margin-bottom: 16px;
    ">
      <div style="font-weight: 600; margin-bottom: 4px;">🎉 Update Available (v${newVersion})</div>
      <div style="font-size: 12px; opacity: 0.9; margin-bottom: 10px;">${notes}</div>
      <button id="downloadUpdate" style="
        background: white;
        color: #0284c7;
        border: none;
        padding: 8px 16px;
        border-radius: 6px;
        font-weight: 500;
        cursor: pointer;
        font-size: 13px;
      ">Download Update</button>
      <button id="dismissUpdate" style="
        background: transparent;
        color: white;
        border: 1px solid rgba(255,255,255,0.3);
        padding: 8px 12px;
        border-radius: 6px;
        margin-left: 8px;
        cursor: pointer;
        font-size: 13px;
      ">Later</button>
    </div>
  `;
  
  const container = document.querySelector('.container');
  container.insertBefore(banner, container.children[1]);
  
  document.getElementById('downloadUpdate').addEventListener('click', () => {
    window.open(DOWNLOAD_URL, '_blank');
  });
  
  document.getElementById('dismissUpdate').addEventListener('click', () => {
    banner.remove();
  });
}

// ============================================
// PAGE DETECTION
// ============================================
async function checkCurrentPage() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url) return;
    
    const url = tab.url;
    
    if (url.includes('charts/patients/add')) {
      pageIndicator.textContent = '📝 Ready to fill patient demographics';
      pageIndicator.style.display = 'block';
    } else if (url.includes('/schedule')) {
      pageIndicator.textContent = '📅 Ready to fill appointment';
      pageIndicator.style.display = 'block';
    } else if (url.includes('/charts/') && url.includes('/documents')) {
      pageIndicator.textContent = '📄 Ready to upload documents';
      pageIndicator.style.display = 'block';
    } else if (url.includes('practicefusion.com')) {
      pageIndicator.style.display = 'none';
    } else {
      pageIndicator.textContent = '⚠️ Open Practice Fusion to use this extension';
      pageIndicator.style.display = 'block';
      pageIndicator.style.background = '#fef2f2';
      pageIndicator.style.color = '#dc2626';
    }
  } catch (e) {
    console.log('Page check error:', e);
  }
}

// ============================================
// SEARCH
// ============================================
function handleSearch() {
  clearTimeout(searchTimeout);
  const query = searchInput.value.trim();
  
  if (query.length < 2) {
    patientList.innerHTML = '';
    actionsSection.style.display = 'none';
    appointmentsSection.style.display = 'none';
    return;
  }
  
  searchTimeout = setTimeout(() => searchPatients(query), 300);
}

async function searchPatients(query) {
  showStatus('Searching...', 'info');
  
  try {
    // Clean phone number for search
    const cleanQuery = query.replace(/\D/g, '');
    const isPhoneSearch = cleanQuery.length >= 7;
    
    let url;
    if (isPhoneSearch) {
      // Search by phone (last 7 digits)
      const last7 = cleanQuery.slice(-7);
      url = `${SUPABASE_URL}/rest/v1/intakes?phone=ilike.*${last7}*&select=*&limit=20`;
    } else {
      // Search by name
      const nameParts = query.toLowerCase().split(' ').filter(p => p.length > 0);
      if (nameParts.length >= 2) {
        url = `${SUPABASE_URL}/rest/v1/intakes?first_name=ilike.*${nameParts[0]}*&last_name=ilike.*${nameParts[1]}*&select=*&limit=20`;
      } else {
        url = `${SUPABASE_URL}/rest/v1/intakes?or=(first_name.ilike.*${nameParts[0]}*,last_name.ilike.*${nameParts[0]}*)&select=*&limit=20`;
      }
    }
    
    const response = await fetch(url, {
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    });
    
    if (!response.ok) throw new Error('Search failed');
    
    const patients = await response.json();
    
    if (patients.length === 0) {
      patientList.innerHTML = '<div class="no-results">No patients found</div>';
      showStatus('', '');
      return;
    }
    
    displayPatients(patients);
    showStatus('', '');
  } catch (error) {
    console.error('Search error:', error);
    showStatus('Search failed. Please try again.', 'error');
  }
}

function displayPatients(patients) {
  patientList.innerHTML = patients.map(p => `
    <div class="patient-card" data-id="${p.id}">
      <div class="patient-name">${p.first_name} ${p.last_name}</div>
      <div class="patient-info">
        <span>📞 ${formatPhone(p.phone)}</span>
        <span>🎂 ${formatDate(p.date_of_birth)}</span>
        ${p.email ? `<span>✉️ ${p.email}</span>` : ''}
      </div>
    </div>
  `).join('');
  
  // Add click handlers
  patientList.querySelectorAll('.patient-card').forEach(card => {
    card.addEventListener('click', () => selectPatient(card.dataset.id, patients));
  });
}

async function selectPatient(id, patients) {
  const patient = patients.find(p => p.id === id);
  if (!patient) return;
  
  // Update UI
  patientList.querySelectorAll('.patient-card').forEach(c => c.classList.remove('selected'));
  patientList.querySelector(`[data-id="${id}"]`)?.classList.add('selected');
  
  // Fetch documents for this patient
  showStatus('Loading documents...', 'info');
  patient.documents = await fetchPatientDocuments(
    patient.id, 
    patient.phone, 
    patient.email,
    patient.first_name?.trim(),
    patient.last_name?.trim()
  );
  
  selectedPatient = patient;
  selectedAppointment = null;
  
  // Display documents inline
  if (patient.documents?.length > 0) {
    documentsSection.style.display = 'block';
    documentsList.innerHTML = patient.documents.map(doc => {
      const isImage = doc.isImage || doc.url?.match(/\.(png|jpg|jpeg|gif|webp)$/i) || doc.url?.includes('/photo-ids/');
      const iconColor = isImage ? '#2563eb' : '#dc2626';
      const iconBg = isImage ? '#dbeafe' : '#fee2e2';
      const icon = isImage 
        ? `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="${iconColor}" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>`
        : `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="${iconColor}" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>`;
      
      return `
        <div class="doc-item">
          <div style="display:flex;align-items:center;gap:8px;">
            <div style="background:${iconBg};padding:6px;border-radius:6px;display:flex;">${icon}</div>
            <span class="doc-name">${doc.type}</span>
          </div>
          <a href="${doc.url}" target="_blank" class="doc-link">Open</a>
        </div>
      `;
    }).join('');
  } else {
    documentsSection.style.display = 'none';
  }
  
  // Show actions
  actionsSection.style.display = 'flex';
  showStatus('', '');
}

// ============================================
// FETCH DOCUMENTS
// ============================================
async function fetchPatientDocuments(patientId, phone, email, firstName, lastName) {
  const allDocs = [];
  
  // Trim whitespace from names
  firstName = firstName?.trim();
  lastName = lastName?.trim();
  
  console.log('🔍 Fetching documents for:', { patientId, phone, email, firstName, lastName });
  
  // 1. Get intake PDF and Photo ID
  try {
    const intakeUrl = `${SUPABASE_URL}/rest/v1/intakes?id=eq.${patientId}&select=pdf_url,photo_id_url`;
    const intakeRes = await fetch(intakeUrl, {
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    });
    const intakes = await intakeRes.json();
    if (intakes?.[0]?.pdf_url) {
      allDocs.push({
        type: 'Medical Intake Form',
        url: intakes[0].pdf_url
      });
    }
    if (intakes?.[0]?.photo_id_url) {
      allDocs.push({
        type: "Driver's License / Photo ID",
        url: intakes[0].photo_id_url,
        isImage: true
      });
    }
  } catch (e) {
    console.log('Intake fetch error:', e);
  }
  
  // 2. Get consents - try multiple search methods
  try {
    // Try by phone first
    if (phone) {
      const cleanPhone = phone.replace(/\D/g, '');
      const consentsUrl = `${SUPABASE_URL}/rest/v1/consents?phone=ilike.*${cleanPhone.slice(-7)}*&select=consent_type,pdf_url`;
      console.log('Trying phone search with:', cleanPhone.slice(-7));
      const consentsRes = await fetch(consentsUrl, {
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
        }
      });
      const consents = await consentsRes.json();
      console.log('Found by phone:', consents?.length || 0);
      if (consents?.length) {
        consents.forEach(c => {
          if (c.pdf_url) {
            allDocs.push({
              type: c.consent_type || 'Consent Form',
              url: c.pdf_url
            });
          }
        });
      }
    }
    
    // If no consents found by phone, try email
    if (allDocs.length <= 1 && email) {
      const emailUrl = `${SUPABASE_URL}/rest/v1/consents?email=ilike.${encodeURIComponent(email)}&select=consent_type,pdf_url`;
      console.log('Trying email search with:', email);
      const emailRes = await fetch(emailUrl, {
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
        }
      });
      const emailConsents = await emailRes.json();
      console.log('Found by email:', emailConsents?.length || 0);
      if (emailConsents?.length) {
        emailConsents.forEach(c => {
          if (c.pdf_url && !allDocs.find(d => d.url === c.pdf_url)) {
            allDocs.push({
              type: c.consent_type || 'Consent Form',
              url: c.pdf_url
            });
          }
        });
      }
    }
    
    // If still no consents, try name
    if (allDocs.length <= 1 && firstName && lastName) {
      const nameUrl = `${SUPABASE_URL}/rest/v1/consents?first_name=ilike.${encodeURIComponent(firstName)}&last_name=ilike.${encodeURIComponent(lastName)}&select=consent_type,pdf_url`;
      console.log('Trying name search with:', firstName, lastName);
      const nameRes = await fetch(nameUrl, {
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
        }
      });
      const nameConsents = await nameRes.json();
      console.log('Found by name:', nameConsents?.length || 0);
      if (nameConsents?.length) {
        nameConsents.forEach(c => {
          if (c.pdf_url && !allDocs.find(d => d.url === c.pdf_url)) {
            allDocs.push({
              type: c.consent_type || 'Consent Form',
              url: c.pdf_url
            });
          }
        });
      }
    }
  } catch (e) {
    console.log('Consents fetch error:', e);
  }
  
  console.log('✅ Final document count:', allDocs.length);
  return allDocs;
}

// ============================================
// ACTIONS - FILL DEMOGRAPHICS
// ============================================
async function fillDemographics() {
  if (!selectedPatient) {
    showStatus('Please select a patient first', 'error');
    return;
  }
  
  showStatus('Filling demographics...', 'info');
  
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  const patient = {
    firstName: selectedPatient.first_name?.trim(),
    lastName: selectedPatient.last_name?.trim(),
    email: selectedPatient.email,
    phone: selectedPatient.phone,
    dob: selectedPatient.date_of_birth,
    gender: selectedPatient.gender,
    address: selectedPatient.street_address,
    city: selectedPatient.city,
    state: selectedPatient.state,
    zip: selectedPatient.postal_code
  };
  
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: fillPFDemographics,
      args: [patient]
    });
    showStatus('✓ Demographics filled!', 'success');
  } catch (error) {
    console.error('Fill error:', error);
    showStatus('Failed to fill. Make sure you\'re on the Add Patient page.', 'error');
  }
}

// Function injected into Practice Fusion page
function fillPFDemographics(patient) {
  console.log('🏥 Filling demographics for:', patient);
  
  // Helper to find input by label text
  function findByLabel(labelText) {
    const labels = document.querySelectorAll('label');
    for (const label of labels) {
      if (label.textContent.toUpperCase().includes(labelText.toUpperCase())) {
        const forId = label.getAttribute('for');
        if (forId) {
          return document.getElementById(forId);
        }
        const input = label.querySelector('input, select');
        if (input) return input;
        const next = label.nextElementSibling;
        if (next?.tagName === 'INPUT' || next?.tagName === 'SELECT') return next;
      }
    }
    return null;
  }
  
  // Helper to find input by data-element attribute (Practice Fusion specific)
  function findByDataElement(elementName) {
    return document.querySelector(`[data-element="${elementName}"]`);
  }
  
  // Helper to set value and trigger events
  function setVal(el, val) {
    if (!el || !val) return false;
    el.value = val;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  }
  
  // Helper to click radio button by value
  function setRadio(name, value) {
    const radios = document.querySelectorAll(`input[type="radio"]`);
    for (const radio of radios) {
      const label = radio.closest('label') || document.querySelector(`label[for="${radio.id}"]`);
      if (label?.textContent.toLowerCase().includes(value.toLowerCase())) {
        radio.click();
        return true;
      }
    }
    return false;
  }
  
  // Helper to set dropdown
  function setDropdown(el, value) {
    if (!el || !value) return false;
    const options = el.querySelectorAll('option');
    for (const opt of options) {
      if (opt.textContent.toLowerCase().includes(value.toLowerCase()) ||
          opt.value.toLowerCase() === value.toLowerCase()) {
        el.value = opt.value;
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      }
    }
    return false;
  }
  
  let filled = 0;
  
  // Fill each field - try data-element first, then label
  if (setVal(findByDataElement('first-name') || findByLabel('FIRST'), patient.firstName)) filled++;
  if (setVal(findByDataElement('last-name') || findByLabel('LAST'), patient.lastName)) filled++;
  if (setVal(findByDataElement('email-address') || findByLabel('EMAIL'), patient.email)) filled++;
  if (setVal(findByDataElement('mobile-phone') || findByLabel('MOBILE'), patient.phone?.replace(/\D/g, ''))) filled++;
  if (setVal(findByDataElement('address-line1') || findByLabel('ADDRESS LINE 1'), patient.address)) filled++;
  if (setVal(findByDataElement('city') || findByLabel('CITY'), patient.city)) filled++;
  if (setVal(findByDataElement('zip') || findByLabel('ZIP'), patient.zip)) filled++;
  
  // Date of birth - may need special formatting
  if (patient.dob) {
    const dobField = findByDataElement('date-of-birth') || findByLabel('DATE OF BIRTH') || findByLabel('DOB');
    if (dobField) {
      // Try MM/DD/YYYY format
      const [year, month, day] = patient.dob.split('-');
      const formatted = `${month}/${day}/${year}`;
      if (setVal(dobField, formatted)) filled++;
    }
  }
  
  // State dropdown
  const stateField = findByDataElement('state') || findByLabel('STATE');
  if (stateField && patient.state) {
    if (stateField.tagName === 'SELECT') {
      setDropdown(stateField, patient.state);
      filled++;
    } else {
      setVal(stateField, patient.state);
      filled++;
    }
  }
  
  // Gender radio
  if (patient.gender) {
    if (setRadio('sex', patient.gender) || setRadio('gender', patient.gender)) {
      filled++;
    }
  }
  
  console.log(`✅ Filled ${filled} fields`);
  return { success: true, fieldsSet: filled };
}

// ============================================
// ACTIONS - UPLOAD DOCUMENTS
// ============================================
async function uploadDocuments() {
  if (!selectedPatient?.documents?.length) {
    showStatus('No documents available for this patient', 'error');
    return;
  }
  
  showStatus('Loading documents...', 'info');
  
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  const docs = selectedPatient.documents;
  const patientName = `${selectedPatient.first_name} ${selectedPatient.last_name}`;
  
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: createDocumentPanel,
      args: [docs, patientName]
    });
    showStatus(`✓ ${docs.length} document(s) ready!`, 'success');
  } catch (error) {
    console.error('Document panel error:', error);
    showStatus('Failed to open document panel', 'error');
  }
}

// Function injected into page to create document panel
function createDocumentPanel(docs, patientName) {
  // Remove existing panel
  const existing = document.getElementById('range-doc-panel');
  if (existing) existing.remove();
  
  const panel = document.createElement('div');
  panel.id = 'range-doc-panel';
  panel.innerHTML = `
    <div style="
      position: fixed;
      top: 20px;
      right: 20px;
      width: 320px;
      background: white;
      border-radius: 12px;
      box-shadow: 0 4px 24px rgba(0,0,0,0.15);
      z-index: 999999;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    ">
      <div style="
        padding: 16px;
        border-bottom: 1px solid #e2e8f0;
        display: flex;
        justify-content: space-between;
        align-items: center;
      ">
        <div>
          <div style="font-weight: 600; color: #0f172a;">Documents</div>
          <div style="font-size: 12px; color: #64748b;">${patientName}</div>
        </div>
        <button id="range-close-panel" style="
          background: none;
          border: none;
          font-size: 20px;
          cursor: pointer;
          color: #94a3b8;
          padding: 4px;
        ">×</button>
      </div>
      <div style="padding: 12px; max-height: 400px; overflow-y: auto;">
        <div style="
          background: #eff6ff;
          padding: 10px;
          border-radius: 8px;
          margin-bottom: 12px;
          font-size: 12px;
          color: #1e40af;
        ">
          Click "Open PDF" to view, then save and upload to Practice Fusion
        </div>
        ${docs.map(doc => `
          <div style="
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            background: #f8fafc;
            border-radius: 8px;
            margin-bottom: 8px;
          ">
            <div>
              <div style="font-weight: 500; font-size: 13px; color: #0f172a;">${doc.type}</div>
            </div>
            <a href="${doc.url}" target="_blank" style="
              display: inline-flex;
              align-items: center;
              gap: 6px;
              padding: 8px 12px;
              background: #0ea5e9;
              color: white;
              text-decoration: none;
              border-radius: 6px;
              font-size: 12px;
              font-weight: 500;
            ">Open PDF</a>
          </div>
        `).join('')}
      </div>
    </div>
  `;
  
  document.body.appendChild(panel);
  
  // Close button handler
  document.getElementById('range-close-panel').addEventListener('click', () => {
    panel.remove();
  });
}

// ============================================
// ACTIONS - FILL APPOINTMENT
// ============================================
async function fillAppointment() {
  if (!selectedPatient) {
    showStatus('Please select a patient first', 'error');
    return;
  }
  
  showStatus('Filling appointment...', 'info');
  
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  const patientName = `${selectedPatient.first_name} ${selectedPatient.last_name}`;
  
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: fillPFAppointment,
      args: [patientName]
    });
    showStatus('✓ Patient name filled!', 'success');
  } catch (error) {
    console.error('Appointment fill error:', error);
    showStatus('Failed to fill. Make sure appointment dialog is open.', 'error');
  }
}

// Function injected to fill appointment
function fillPFAppointment(patientName) {
  console.log('🏥 Filling appointment for:', patientName);
  
  // Try to find patient search field in appointment dialog
  const searchFields = document.querySelectorAll('input[type="text"], input[placeholder*="patient" i], input[placeholder*="search" i]');
  
  for (const field of searchFields) {
    if (field.offsetParent !== null) { // Visible
      field.value = patientName;
      field.dispatchEvent(new Event('input', { bubbles: true }));
      field.dispatchEvent(new Event('change', { bubbles: true }));
      field.focus();
      console.log('✅ Filled patient search field');
      return { success: true };
    }
  }
  
  console.log('❌ Could not find patient search field');
  return { success: false };
}

// ============================================
// UTILITIES
// ============================================
function showStatus(message, type) {
  if (!message) {
    statusEl.style.display = 'none';
    return;
  }
  statusEl.textContent = message;
  statusEl.className = `status ${type}`;
}

function formatPhone(phone) {
  if (!phone) return '';
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.length === 10) {
    return `(${cleaned.slice(0,3)}) ${cleaned.slice(3,6)}-${cleaned.slice(6)}`;
  }
  return phone;
}

function formatDate(dateStr) {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-');
  return `${month}/${day}/${year}`;
}
